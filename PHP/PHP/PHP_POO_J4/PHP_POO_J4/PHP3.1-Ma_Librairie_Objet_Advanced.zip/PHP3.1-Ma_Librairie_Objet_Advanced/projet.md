## Enoncé de l'exercice PHP3.1

![projet](./images/projet.png)

> Soit à reprendre le projet abouti d'authentification du chapitre PHP2.2.
> Vous allez apliquer chacune des technologies vues dans ce chapitre à celui-ci.
* Type hinting
* Fonctions variables et décomposition
* Valeurs par défaut
* Passage par référence
* et surtout typage strict !

Maintenant, cela devrait être une formalité pour vous !